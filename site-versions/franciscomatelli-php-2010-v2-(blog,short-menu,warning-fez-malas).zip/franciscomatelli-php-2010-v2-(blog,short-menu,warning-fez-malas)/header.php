<div id="warning">
	<div class="cell" id="c1">
		<img src="briefcase.png" alt="Malas prontas! Estou na F5 Sites" />	
	</div>
	<div class="cell" id="c2">
		<p>Francisco Matelli fez as malas! Estou a frente da <a href="http://www.f5sites.com" alt="Visitar o site da F5 Sites">Ag&ecirc;ncia F5 Sites, venha conhecer!</a></p>
		<small>O <a href="contato.php" alt="Entrar em contato com Francisco Matelli">formul&aacute;rio de contato</a> continua habilitado, contatos profissionais agora somente para consultoria!</small>
	</div>
	<div class="cell" id="c3">
		<img src="home.png" />
	</div>
</div>
<div id="header">
	<a href="index.php"><img src="imagens/logo.png" alt="Francisco Matelli (Logotipo)"/></a>
</div>
