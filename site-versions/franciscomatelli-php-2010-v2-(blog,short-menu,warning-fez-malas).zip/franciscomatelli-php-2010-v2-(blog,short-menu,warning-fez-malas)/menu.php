<table id="tabelaMenu">
	<tr>
		<td>
			<div id="menu">
				<ul>
					<li id="destaque"><a href="index.php">Home</a></li>
					<li><a href="blog/">Blog</a></li>
					<li><a href="clientes.php">Clientes</a></li>
					
					<li><a href="portfolio.php">Portfolio</a></li>
					<!--<li>
					<li><a href="/servicos.php">Servi&ccedil;os</a></li>
					<a href="/index.php">Projetos</a></li>
					<li><a href="/index.php">Advergames</a></li>
					<li><a href="/promocao.php">Promo&ccedil;&atilde;o</a></li>-->
					<li><a href="vtiger.php">vTigerCRM</a></li>
					<li><a href="contato.php">Contato</a></li>
				</ul>
			</div>
		</td>
	</tr>
</table>
