<?php
// ** MySQL settings ** //
define('DB_NAME', 'f5sites_wrdp1');    // The name of the database
define('DB_USER', 'root');     // Your MySQL username
define('DB_PASSWORD', 'teste123'); // ...and password
define('DB_HOST', 'localhost');    // 99% chance you won't need to change this value
define('DB_CHARSET', 'utf8');
define('DB_COLLATE', '');

// Change SECRET_KEY to a unique phrase.  You won't have to remember it later,
// so make it long and complicated.  You can visit http://api.wordpress.org/secret-key/1.0/
// to get a secret key generated for you, or just make something up.
define('SECRET_KEY', 'uVbJ9NORKMGXBdFOsddx1tnRxsyxL1VN7lQ{bkh85veVu4Ub3O3TS8TxsyxL1VN7lQ{qwnSUYcjsiQC6tUtvnyd'); // Change this to a unique phrase.

// You can have multiple installations in one database if you give each a unique prefix
$table_prefix  = 'wp_';   // Only numbers, letters, and underscores please!

// Change this to localize WordPress.  A corresponding MO file for the
// chosen language must be installed to wp-content/languages.
// For example, install de.mo to wp-content/languages and set WPLANG to 'de'
// to enable German language support.
define ('WPLANG', '');

#2016define ("WP_SITEURL", "http://localhost/museu/fm-v2/blog/");
#2016define ("WP_HOME", "http://localhost/museu/fm-v2/blog/");
/* That's all, stop editing! Happy blogging. */

define('ABSPATH', dirname(__FILE__).'/');
require_once(ABSPATH.'wp-settings.php');
?>
