<div id="footer">
	<p>Francisco Matelli - 15 9123-6052 - 16 9247-0701 - <a href="mailto:contato@franciscomatelli.com"> contato@franciscomatelli.com </a>- Araraquara/São Paulo</p>
	<p>
	 	<a href="http://validator.w3.org/check?uri=referer"><img src="http://www.w3.org/Icons/valid-xhtml10-blue" alt="Valid XHTML 1.0 Strict" height="31" width="88" /></a>
		<a href="http://jigsaw.w3.org/css-validator/"><img style="border:0;width:88px;height:31px" src="http://jigsaw.w3.org/css-validator/images/vcss-blue" alt="Valid CSS!" /></a>
 	</p>
</div>