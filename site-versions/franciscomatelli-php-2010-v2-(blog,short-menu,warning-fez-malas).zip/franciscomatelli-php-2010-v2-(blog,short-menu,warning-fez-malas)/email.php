<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<h1>Escreva o destinário</h1>
<form action="email.php" method="post">
<input type="text" name="to" />
<select name='modelo' id='modelo'>
	<option value='1'>Instalação do vTigerCRM</option>
	<option value='2'>Dia 10: Lembrete: Fatura Pronta</option>
</select>
<input type="submit" value="enviar" />
</form>
<?php
if($_POST['modelo']==1) {
	$mensagem = require("resposta-vtiger.html");

	$titulo = 'Instalação do vTigerCRM | Francisco Matelli';
}


$cabecalho = "From:Francisco Matelli <contato@franciscomatelli.com>\r\n";
$cabecalho.= "Content-Type: text/html;\r\n charset=\"iso-8859-1\"\r\n";
		
if(mail($_POST['to'], $titulo, $mensagem, $cabecalho))
$emailComAcerto .= "-".$email;
else
$emailComErro .= "-".$email;
echo "<script>alert(\"Sucesso ao enviar: $emailComAcerto ... Falha ao enviar email para: $emailComErro\")</script>";

?>
</body>
</html>
